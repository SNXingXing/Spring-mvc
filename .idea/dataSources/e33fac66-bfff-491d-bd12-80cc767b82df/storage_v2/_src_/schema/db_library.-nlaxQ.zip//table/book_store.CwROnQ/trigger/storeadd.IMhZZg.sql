create trigger storeAdd
  after INSERT
  on book_store
  for each row
  BEGIN
	update book_isbn set num=num+1 where isbn_id=0;
	UPDATE book_isbn SET num=num+1 WHERE isbn_id=NEW.isbn_id;
	
	
    END;

