create procedure store_add(IN iid int, IN pid int)
  BEGIN	
	insert into book_store (isbn_id,pb_id) values(iid, pid);
    END;

