create view book_info as
  select `i`.`isbn_id`     AS `isbn_id`,
         `i`.`isbn`        AS `isbn`,
         `i`.`b_name`      AS `书名`,
         `p`.`p_name`      AS `出版社`,
         `a`.`a_name`      AS `作者`,
         `c`.`name`        AS `分类`,
         `i`.`publishTime` AS `出版时间`,
         `i`.`edition`     AS `版次`,
         `i`.`num`         AS `库存`
  from (((`db_library`.`book_isbn` `i` join `db_library`.`book_publisher` `p`) join `db_library`.`book_author` `a`) join `db_library`.`book_category` `c`)
  where ((`i`.`p_id` = `p`.`p_id`) and (`i`.`a_id` = `a`.`a_id`) and (`i`.`c_id` = `c`.`id`));

