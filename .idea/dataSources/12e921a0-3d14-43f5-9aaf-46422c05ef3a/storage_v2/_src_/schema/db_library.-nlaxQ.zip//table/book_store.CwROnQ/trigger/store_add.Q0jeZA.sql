create trigger store_add
  after INSERT
  on book_store
  for each row
  BEGIN
	UPDATE book_isbn SET num=num+1 WHERE isbn_id=0;
	UPDATE book_isbn SET num=num+1 WHERE isbn_id=NEW.isbn_id;
	
	
    END;

