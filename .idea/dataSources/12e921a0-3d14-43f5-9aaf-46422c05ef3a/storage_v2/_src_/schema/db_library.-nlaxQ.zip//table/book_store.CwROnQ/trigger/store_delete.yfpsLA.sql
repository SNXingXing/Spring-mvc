create trigger store_delete
  after DELETE
  on book_store
  for each row
  BEGIN
	UPDATE book_isbn SET num = num-1 WHERE isbn_id=0;
	UPDATE book_isbn SET num = num-1 WHERE isbn_id=isbn_id;
    END;

